#!/usr/bin/env python3
"""Restore exact archived tool inputs. Does not compile, install Forge or run a server."""
from pathlib import Path
import hashlib,json,os,tarfile,urllib.request,zipfile
root=Path(__file__).resolve().parent
rows=[]
for name in ('download-provenance.json','package-runtime-downloads.json','powershell-provenance.json'):
 entries=json.loads((root/name).read_text())
 if isinstance(entries,dict):entries=[entries]
 rows.extend(x for x in entries if isinstance(x,dict) and 'file' in x)
for item in rows:
 p=root/item['file']
 if not p.is_file():
  request=urllib.request.Request(item['source'],headers={'User-Agent':'Gradle/8.8'})
  with urllib.request.urlopen(request,timeout=180) as response: blob=response.read()
  assert len(blob)==item['bytes'] and hashlib.sha256(blob).hexdigest()==item['sha256'],item['file']
  p.write_bytes(blob)
 assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['file']
 print('Verified',item['file'],flush=True)
 if p.name=='jdk17.tar.gz':
  with tarfile.open(p) as archive:archive.extractall(root,filter='data')
 elif p.name=='powershell-7.4.6-linux-x64.tar.gz':
  with tarfile.open(p) as archive:archive.extractall(root/'powershell-7.4.6',filter='data')
  (root/'powershell-7.4.6/pwsh').chmod(0o755)
 elif p.name=='gradle-8.8-bin.zip':
  with zipfile.ZipFile(p) as archive:archive.extractall(root)
  (root/'gradle-8.8/bin/gradle').chmod(0o755)
 elif p.name=='windows-jre17.zip':
  with zipfile.ZipFile(p) as archive:archive.extractall(root/'windows-jre17')
print('Pinned tools restored; no compilation or server launched.')
