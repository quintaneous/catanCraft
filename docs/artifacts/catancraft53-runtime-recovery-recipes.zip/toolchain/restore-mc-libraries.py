#!/usr/bin/env python3
from pathlib import Path
import concurrent.futures,hashlib,json,urllib.request,os
root=Path(__file__).resolve().parent.parent
meta=json.loads((root/'catanCraft/build/downloadMCMeta/version.json').read_text())
cache=Path.home()/'.gradle/caches/forge_gradle/maven_downloader'
inputs=[]
for lib in meta['libraries']:
 d=lib.get('downloads',{})
 if d.get('artifact'):inputs.append(d['artifact'])
 inputs.extend(d.get('classifiers',{}).values())
def one(row):
 p=cache/row['path'];url=row['url']
 if p.is_file() and p.stat().st_size==row['size'] and hashlib.sha1(p.read_bytes()).hexdigest()==row['sha1']:return dict(path=row['path'],status='cached',sha1=row['sha1'],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=row['size'],source=url)
 try:
  data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Gradle/8.8'}),timeout=90).read()
  assert len(data)==row['size'] and hashlib.sha1(data).hexdigest()==row['sha1']
  p.parent.mkdir(parents=True,exist_ok=True)
  temp=p.with_name(p.name+'.restore53');temp.write_bytes(data);os.replace(temp,p)
  p.with_name(p.name+'.md5').write_text(hashlib.md5(data).hexdigest())
  return dict(path=row['path'],status='downloaded',sha1=row['sha1'],sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),source=url)
 except Exception as e:return dict(path=row['path'],status='failed',error=str(e),source=url)
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:results=list(pool.map(one,inputs))
report=dict(schema=1,purpose='official-minecraft-version-library-cache-inputs',minecraft='1.20.1',files=results)
(root/'toolchain/mc-libraries-restoration.json').write_text(json.dumps(report,indent=2)+'\n')
counts={status:sum(r['status']==status for r in results) for status in ['cached','downloaded','failed']};print(counts,flush=True)
raise SystemExit(bool(counts['failed']))
