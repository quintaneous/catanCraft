#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,urllib.request,concurrent.futures,time,sys
root=Path(__file__).resolve().parent.parent
meta=json.loads((root/'catanCraft/build/downloadMCMeta/version.json').read_text())['assetIndex']
cache=Path.home()/'.gradle/caches/forge_gradle/assets'
index=cache/'indexes'/f"{meta['id']}.json"
def fetch(url):
 return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Gradle/8.8'}),timeout=90).read()
data=fetch(meta['url'])
assert hashlib.sha1(data).hexdigest()==meta['sha1'] and len(data)==meta['size']
index.parent.mkdir(parents=True,exist_ok=True);index.write_bytes(data)
objects=json.loads(data)['objects'];unique={o['hash']:o for o in objects.values()}
def one(o):
 h=o['hash'];p=cache/'objects'/h[:2]/h
 if p.exists() and p.stat().st_size==o['size'] and hashlib.sha1(p.read_bytes()).hexdigest()==h:return 'cached'
 for attempt in range(3):
  try:
   data=fetch(f'https://resources.download.minecraft.net/{h[:2]}/{h}')
   assert len(data)==o['size'] and hashlib.sha1(data).hexdigest()==h
   p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   return 'downloaded'
  except Exception as e:
   if attempt==2:return {'hash':h,'error':str(e)}
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
workers=int(sys.argv[2]) if len(sys.argv)>2 else 8
counts={};fails=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
 for i,r in enumerate(pool.map(one,list(unique.values())[start:]),1):
  if isinstance(r,dict):fails.append(r)
  else:counts[r]=counts.get(r,0)+1
  if i%250==0:print(i,len(unique),counts,'failures',len(fails),flush=True)
report=dict(schema=1,purpose='official-mojang-assets-restoration',assetIndex=meta,indexSHA256=hashlib.sha256(data).hexdigest(),logicalObjects=len(objects),uniqueObjects=len(unique),counts=counts,failures=fails,cacheRoot=str(cache),start=start)
(root/f'toolchain/assets-restoration{"-tail" if start else ""}.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
raise SystemExit(bool(fails))
