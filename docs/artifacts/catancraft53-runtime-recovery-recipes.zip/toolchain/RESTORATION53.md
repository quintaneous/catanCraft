# CatanCraft 0.1.53 toolchain recovery

This recovery creates development tools, official runtime libraries and published mod inputs only. It does not launch a server, accept the Minecraft EULA, compile CatanCraft or validate gameplay.

Workspace used: `/workspace/scratch/92c934691925`; repository: `catanCraft`.

## Verified downloads

| Input | SHA256 |
|---|---|
| Temurin JDK 17.0.21+9 Linux x64 | `8b9b611d917e3dfd8419d3566b5949226f69b052fed7e109c1368add1dfe8711` |
| Gradle 8.8 binary ZIP | `a4b4158601f8636cdeeab09bd76afb640030bb5b144aafe261a5e8af027dc612` |
| Temurin JRE 17.0.21+9 Windows x64 | `fe4656bd78fb09812dc38c49da777f79cc33e7ee435a254be82f9e7f40d9d117` |
| Forge 1.20.1-47.4.10 installer | `1912760b4cb6b803d8a826de603c9076b1da71ec2765e9a1f8c1ca78f65278e3` |

Download URLs and byte counts are preserved in `download-provenance.json` and `package-runtime-downloads.json`. The main Forge Maven URL returned 403; the official `files.minecraftforge.net/maven/` alias supplied the exact installer. No dependency version was substituted.

Run `python3 toolchain/restore-pinned-tools.py` from a restored recovery bundle to download/hash-verify and extract these exact inputs. This script does not install Forge or launch Gradle.

PowerShell7.4.6 Linux x64 was also restored for package-agent script qualification. Official archive SHA256 `6f6015203c47806c5cc444c19d8ed019695e610fbd948154264bf9ca8e157561` matches the official release `hashes.sha256`; provenance is `powershell-provenance.json`. Executable is `toolchain/powershell-7.4.6/pwsh`.

## Wrapper

Run `python3 /workspace/scratch/92c934691925/run-gradle53.py <tasks> <flags>`.

The wrapper derives the currently active proxy from `HTTPS_PROXY`, trusts the system Java certificate store, uses the restored Java17 and Gradle8.8, and adds a scratch init script pinning ForgeGradle6.0.54. Proxy port must not be hardcoded because it changes between execution sessions. Repository build configuration is not modified by this wrapper.

`tasks --all --console=plain` completed successfully, recorded in `gradle-tasks.log`. This confirms Gradle configuration only. A dry run of `downloadAssets extractNatives` scheduled only `downloadMCMeta`, `downloadAssets` and `extractNatives`, recorded in `gradle-assets-dry-run.log`.

## Published runtime inputs

From repository root:

```bash
python3 tools/sec01_035/prepare_runtime.py
python3 tools/shop42/prepare_tacz_runtime.py
```

Both preparation commands completed exit0. Their inventories are `build/sec01-035-runtime/runtime-artifacts.json` (SHA256 `6e4424ef5a564609dc893c5d9d1ff3efcc7b897d8b9ae9a9acf96d7c331c9452`) and `build/shop42-tacz-runtime/runtime-artifacts.json` (SHA256 `1f3a4c5b31e1c0893f30f333a602b4334a82ba3c25ea23784ab16257b4080891`). The scripts contain exact download source and hash pins. Use original input JARs for a normal Forge distribution, not the development-only extracted jars.

## Dedicated Forge runtime

Run the verified installer under the restored Java17 with current proxy properties and trust store:

```bash
java -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts \
  -Dhttp.proxyHost=HOST -Dhttp.proxyPort=PORT \
  -Dhttps.proxyHost=HOST -Dhttps.proxyPort=PORT \
  -jar toolchain/forge-installer.jar --installServer runtime53/forge
```

Installer completed exit0. `forge-install.log` records installation. The resulting 104 library files are inventoried in `forge53-runtime-manifest.json` (SHA256 `50ef5506215dcb2c652d9c2e27c4d810ae541c4973da03dfafe70730f4257b9b`). This installer invocation performs dependency preparation and patching, not a server launch. No world/EULA was created by this recovery.

## Minecraft assets

`python3 toolchain/restore-assets.py` downloads the asset index named by the official cached Minecraft1.20.1 version metadata, verifies its SHA1 and byte count, then verifies each unique asset against index SHA1 and size. Destination is the standard ForgeGradle cache `~/.gradle/caches/forge_gradle/assets`. Progress is `assets-restoration.log`; final report is `assets-restoration.json`. Any failures are explicit and cause a nonzero exit. No project compilation or game launch is performed.

Final independent verification passed all 3,577 unique objects (3,600 logical entries), 653,961,360 unique bytes, against official SHA1 and size; report: `assets-verification.json`. The first Gradle `downloadAssets extractNatives` attempt failed on 18 proxy tunnel requests while Python recovery completed. The failure is preserved in `gradle-runtime-inputs.log`. A second invocation reused the complete cache and completed exit0, BUILD SUCCESSFUL in21s; log: `gradle-runtime-inputs-02.log`. This confirms asset preparation and native-library extraction only, not gameplay or native-server validation.

## Minecraft Java libraries

`python3 toolchain/restore-mc-libraries.py` verifies official Minecraft version-library inputs against metadata SHA1 and size, and downloads only missing inputs to the ForgeGradle Maven downloader cache. All 88 inputs passed verification; report is `mc-libraries-restoration.json`. This was cache input verification, not a project compile/test.

## Cache state after recovery

Parent subsequently ran CatanCraft compilation separately. Its first offline attempt reached MCP dependency generation but lacked Forge transitive metadata; its online retry completed. The dependency cache is therefore populated for the exact parent compile. This agent did not launch compilation or a game server. Root retains compile evidence separately.
