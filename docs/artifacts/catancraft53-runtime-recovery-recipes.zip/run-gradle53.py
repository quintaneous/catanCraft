#!/usr/bin/env python3
import os,sys,subprocess,urllib.parse
from pathlib import Path
root=Path(__file__).resolve().parent
jdk=root/'toolchain/jdk-17.0.21+9'
env=os.environ.copy();env['JAVA_HOME']=str(jdk);env['PATH']=str(jdk/'bin')+':'+env['PATH']
proxy=urllib.parse.urlparse(env.get('HTTPS_PROXY',env.get('https_proxy','')))
opts=['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts']
if proxy.hostname:
 opts += ['-Dhttp.proxyHost='+proxy.hostname,'-Dhttp.proxyPort='+str(proxy.port),'-Dhttps.proxyHost='+proxy.hostname,'-Dhttps.proxyPort='+str(proxy.port)]
env['GRADLE_OPTS']=' '.join(opts);env['JAVA_TOOL_OPTIONS']=' '.join(opts)
cmd=[str(root/'toolchain/gradle-8.8/bin/gradle'),'-I',str(root/'toolchain/pin-forgegradle.init.gradle'),*sys.argv[1:]]
raise SystemExit(subprocess.run(cmd,cwd=root/'catanCraft',env=env).returncode)
