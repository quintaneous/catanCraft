import json,pathlib,re,subprocess,sys,time,hashlib
repo=pathlib.Path('/workspace/scratch/a1b6a42f71e7/catanCraft')
source='55d1b5afb259e9f60858af4a414695675e92bc50'
label='shop51-round1'
out=repo/'build/shop51-evidence'/label
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert not (repo/'build'/('validation-'+label)).exists(), 'Never reuse a previous fresh run'
out.mkdir()
wrapper='/workspace/scratch/a1b6a42f71e7/run-gradle50-original.py'
suites=[('catancraft_shop51',9,[]),('catancraft_shop40',35,[]),('catancraft_rewards41',32,[]),('catancraft_claims43',10,[]),('catancraft_supply43',8,[]),('catancraft_active44',6,[]),('catancraft_stock42',8,[])]
for phase in ['seed','verify']:
 suites.append(('catancraft_shop40_restart',1,['-PshopRestartPhase='+phase,'-PshopRestartSource='+source]))
for phase in ['seed','verify']:
 suites.append(('catancraft_rewards41_restart',1,['-PrewardsRestartPhase='+phase,'-PrewardsRestartSource='+source]))
results=[]
for index,(namespace,expected,extra) in enumerate(suites,1):
 name=f'{index:02d}-{namespace}'
 path=out/(name+'.log')
 command=[sys.executable,wrapper,'runGameTestServer','--offline','-PcontrolledGameTests=true','-PcontrolledRunLabel='+label,'-PgameTestNamespace='+namespace,*extra]
 started=time.time()
 print('RUN',name,'expected',expected,flush=True)
 with path.open('x') as log:code=subprocess.call(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 text=path.read_text()
 completed=re.findall(r'(\d+) GAME TESTS COMPLETE',text)
 passed=code==0 and completed and int(completed[-1])==expected and f'All {expected} required tests passed' in text
 result={'name':name,'namespace':namespace,'expected':expected,'executed':int(completed[-1]) if completed else 0,'exit':code,'passed':bool(passed),'seconds':round(time.time()-started,2),'command':command,'logSHA256':hashlib.sha256(path.read_bytes()).hexdigest()}
 results.append(result)
 (out/'results.json').write_text(json.dumps({'sourceCommit':source,'label':label,'results':results},indent=2)+'\n')
 print(json.dumps(result),flush=True)
 if not passed:
  print('STOP: failed attempt retained; inspect original log',str(path),flush=True)
  sys.exit(code or 1)
print('VALIDATED_PHASE_EXECUTIONS',sum(r['executed'] for r in results),flush=True)
