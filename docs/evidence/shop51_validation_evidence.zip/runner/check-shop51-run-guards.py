from pathlib import Path
import hashlib,json,subprocess,sys
repo=Path('/workspace/scratch/a1b6a42f71e7/catanCraft')
out=repo/'build/shop51-evidence/shop51-round1'
wrapper='/workspace/scratch/a1b6a42f71e7/run-gradle50-original.py'
linkbase=repo/'build/validation-shop51-refuse-link'
linkbase.mkdir()
target=out/'symlink-target';target.mkdir();(target/'keep.txt').write_bytes(b'PRESERVE LINK TARGET')
(linkbase/'build').symlink_to(target,target_is_directory=True)
unknown=repo/'build/validation-shop51-refuse-unknown/build/controlled-catancraft_shop51-run/world'
unknown.mkdir(parents=True);(unknown/'level.dat').write_bytes(b'UNKNOWN SAVE MUST REMAIN')
cases=[('unsafe-label',['help','-PcontrolledGameTests=true','-PcontrolledRunLabel=../invalid'],'controlledRunLabel requires'),('uncontrolled-label',['help','-PcontrolledRunLabel=shop51-refuse-uncontrolled'],'controlledRunLabel requires'),('linked-path',['prepareContractGameTestWorld','-PcontrolledGameTests=true','-PcontrolledRunLabel=shop51-refuse-link','-PgameTestNamespace=catancraft_shop51'],'refuses symlink paths'),('unknown-save',['prepareContractGameTestWorld','-PcontrolledGameTests=true','-PcontrolledRunLabel=shop51-refuse-unknown','-PgameTestNamespace=catancraft_shop51'],'Unrecognized existing GameTest save')]
results=[]
for name,args,reason in cases:
 log=out/('guard-'+name+'.log');command=[sys.executable,wrapper,*args,'--offline']
 with log.open('x') as output:code=subprocess.call(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
 text=log.read_text();ok=code!=0 and reason in text
 result={'case':name,'expectedRefusal':True,'exit':code,'passed':ok,'reason':reason,'log':log.name,'logSHA256':hashlib.sha256(log.read_bytes()).hexdigest()}
 results.append(result);print(json.dumps(result),flush=True)
 (out/'run-guard-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if not ok:raise SystemExit(1)
assert (target/'keep.txt').read_bytes()==b'PRESERVE LINK TARGET' and len(list(target.iterdir()))==1
assert (unknown/'level.dat').read_bytes()==b'UNKNOWN SAVE MUST REMAIN'
assert not (unknown.parent/'.catancraft-controlled-fixture-v1').exists()
assert not (unknown.parent/'server.properties').exists()
print('All four expected refusals verified; existing target bytes unchanged; no server launched',flush=True)
