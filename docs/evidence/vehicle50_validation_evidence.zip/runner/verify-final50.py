import pathlib,json,hashlib,subprocess,zipfile,re,sys
repo=pathlib.Path('/workspace/scratch/a1b6a42f71e7/catanCraft');p=repo/'build/vehicle50-evidence/final';source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
base=json.loads((p/'compiled-540919.json').read_text());now={}
for folder in ('build/classes/java/main','build/resources/main'):
 for f in sorted((repo/folder).rglob('*')):
  if f.is_file():now[str(f.relative_to(repo))]=hashlib.sha256(f.read_bytes()).hexdigest()
assert now.keys()==base['files'].keys(),'Compiled inventory changed'
changed=[f for f in now if now[f]!=base['files'][f]]
assert set(changed)=={'build/classes/java/main/com/quin/catancraft/world/VehicleService50Tests.class','build/classes/java/main/com/quin/catancraft/world/VehicleService50Tests$Fixture.class','build/classes/java/main/com/quin/catancraft/world/NativeVehicleRoad50Tests.class','build/classes/java/main/com/quin/catancraft/world/NativeVehicleRoad50Tests$Run.class'},changed
assert subprocess.check_output(['git','diff','--name-only',base['source'],source],cwd=repo,text=True).splitlines()==['src/main/java/com/quin/catancraft/world/NativeVehicleRoad50Tests.java','src/main/java/com/quin/catancraft/world/VehicleService50Tests.java','tools/vehicle50/validate_combined.gradle']
jar=repo/'build/libs/catancraft-0.1.50-vehicle-service.jar';assert jar.is_file()
with zipfile.ZipFile(jar) as z:
 assert z.testzip() is None
 mf=z.read('META-INF/MANIFEST.MF').decode().replace('\r\n ','').replace('\n ','');assert f'CatanCraft-Source-Commit: {source}' in mf;assert 'MixinConfigs: catancraft.mixins.json' in mf
 assert '0.1.50-vehicle-service' in z.read('META-INF/mods.toml').decode()
 mixins=json.loads(z.read('catancraft.mixins.json'));assert z.read('catancraft.mixins.json')==(repo/'src/main/resources/catancraft.mixins.json').read_bytes()
 for name in mixins['mixins']:assert f"com/quin/catancraft/mixin/{name}.class" in z.namelist()
 for name in ('VehicleService50','VehicleFactory50','PhysicalVehicleShop50','VehicleService50Events','VehicleFuel49','VehicleRefueling49'):
  assert f'com/quin/catancraft/world/{name}.class' in z.namelist()
 classes=[n for n in z.namelist() if n.endswith('.class')];assert len(classes)==sum(f.endswith('.class') for f in now)
 for name in classes:assert z.read(name)[:8]==b'\xca\xfe\xba\xbe\x00\x00\x00=' # Java17
 # Every raw data/asset resource retains its exact source bytes.
 assets=0
 for folder in ('data','assets'):
  for f in (repo/'src/main/resources'/folder).rglob('*'):
   if f.is_file():assert z.read(str(f.relative_to(repo/'src/main/resources')))==f.read_bytes();assets+=1
 log=(p/'build.log').read_text();assert 'BUILD SUCCESSFUL' in log and '> Task :reobfJar' in log
 v={'source':source,'jar':jar.name,'jar_bytes':jar.stat().st_size,'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'zip_crc':'PASS','source_stamp':'PASS','version':'0.1.50-vehicle-service','java17_classes':len(classes),'original_resources_verified':assets,'mixins':mixins['mixins'],'reobfuscation_task':'PASS','regression_source':base['source'],'compiled_files_unchanged':len(now)-len(changed),'compiled_files_changed':changed,'production_bytes_unchanged':True}
(p/'artifact-verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
