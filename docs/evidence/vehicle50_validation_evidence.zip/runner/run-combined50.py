import json,pathlib,sys,subprocess
source=sys.argv[1];root=pathlib.Path('build/vehicle50-evidence/final');results=[]
suites=[('combined_service','catancraft_service50',8,[]),('combined_service_seed','catancraft_service50_restart',1,['-Pservice50Phase=seed','-Pservice50Source='+source]),('combined_service_verify','catancraft_service50_restart',1,['-Pservice50Phase=verify','-Pservice50Source='+source]),('combined_road','catancraft_vehicle50_road',8,['-Pvehicle50Source='+source])]
for label,ns,n,extra in suites:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
 logpath=root/(label+'.log');assert not logpath.exists()
 with logpath.open('w') as log:code=subprocess.call(['python3','/workspace/scratch/a1b6a42f71e7/run-gradle50.py','runGameTestServer','-PcontrolledGameTests=true','-PgameTestNamespace='+ns,'-I','tools/vehicle50/validate_combined.gradle']+extra,stdout=log,stderr=subprocess.STDOUT)
 text=logpath.read_text();ok=code==0 and f'{n} GAME TESTS COMPLETE' in text and f'All {n} required tests passed' in text
 if label=='combined_service':ok=ok and 'SERVICE50_COMBINED_RUNTIME_PASS tacz=true superbwarfare=true simplebedrockmodel=2.6.2-forge-mc1.20.1 runtimeArtifacts=15' in text
 results.append(dict(label=label,namespace=ns,expected=n,exit=code,passed=ok,source=source));(root/'combined-results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,code,ok,flush=True)
 if not ok:raise SystemExit(1)
