import subprocess,json,pathlib,sys
source=sys.argv[1];root=pathlib.Path('build/vehicle50-evidence/final');root.mkdir(parents=True,exist_ok=True)
suites=[]
def add(ns,n,init=None,extra=(),label=None):
 suites.append((label or ns,ns,n,(['-I',init] if init else [])+list(extra)))
add('catancraft_service50',7,'tools/vehicle50/validate.gradle')
for phase in ('seed','verify'):add('catancraft_service50_restart',1,'tools/vehicle50/validate.gradle',['-Pservice50Phase='+phase,'-Pservice50Source='+source],label='service_'+phase)
add('catancraft_factory50',3,'tools/vehicle50/validate.gradle');add('catancraft_vehicle50_ui',3)
add('catancraft_sbw',7,'tools/sec01_035/validate.gradle')
for phase in ('seed','verify'):add('catancraft_sbw_procurement35',1,'tools/sec01_035/validate.gradle',['-PsbwRestartPhase='+phase],label='procurement_'+phase)
add('catancraft_handheld44',7,'tools/shop44/validate_combined.gradle')
add('catancraft_native42_tacz',8,'tools/shop42/validate_tacz.gradle')
for phase in ('seed','verify'):add('catancraft_native42_tacz_restart',1,'tools/shop42/validate_tacz.gradle',['-Pnative42RestartPhase='+phase,'-Pnative42RestartProvider=tacz','-Pnative42RestartSource='+source],label='tacz_'+phase)
add('catancraft_active44',6);add('catancraft_stock42',8);add('catancraft_shop40',35)
for phase in ('seed','verify'):add('catancraft_shop40_restart',1,None,['-PshopRestartPhase='+phase,'-PshopRestartSource='+source],label='shop_'+phase)
add('catancraft_rewards41',32);add('catancraft_claims43',10);add('catancraft_supply43',8)
add('catancraft_vehicle47',4,'tools/vehicle47/validate.gradle',['-Pvehicle47RestartSource='+source])
for phase in ('seed','verify'):add('catancraft_vehicle47_restart',1,'tools/vehicle47/validate.gradle',['-Pvehicle47RestartPhase='+phase,'-Pvehicle47RestartSource='+source],label='vehicle47_'+phase)
add('catancraft_vehicle47_exit',6,'tools/vehicle47/validate.gradle');add('catancraft_vehicle46',18);add('catancraft_vehicle46_native',6,'tools/vehicle46/validate.gradle')
add('catancraft_vehicle45',8);add('catancraft_economy45',6);add('catancraft_economy_clock',9)
add('catancraft_paid_recovery',19);add('catancraft_construction34',28);add('catancraft_startup34',3);add('catancraft',50)
results=[]
for label,ns,count,extra in suites:
 if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=source:raise RuntimeError('Source changed')
 logpath=root/(label+'.log')
 if logpath.exists():raise RuntimeError('Preserve previous evidence before rerunning '+label)
 cmd=['python3','/workspace/scratch/a1b6a42f71e7/run-gradle50.py','runGameTestServer','-PcontrolledGameTests=true','-PgameTestNamespace='+ns]+extra
 with logpath.open('w') as log: code=subprocess.call(cmd,stdout=log,stderr=subprocess.STDOUT)
 text=logpath.read_text();ok=code==0 and f'{count} GAME TESTS COMPLETE' in text and f'All {count} required tests passed' in text
 results.append(dict(label=label,namespace=ns,expected=count,exit=code,passed=ok,source=source));(root/'results.json').write_text(json.dumps(results,indent=2));print(label,code,ok,flush=True)
 if not ok:raise SystemExit(1)
print('ALL',sum(r['expected'] for r in results),'phases passed',flush=True)
