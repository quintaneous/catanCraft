import json,pathlib,subprocess
root=pathlib.Path('build/vehicle50-evidence/final');results=[];source='54091940597e054e8eb5953e280ef46807f67014'
for label,ns,n in [('startup_retry','catancraft_startup34',3),('catancraft','catancraft',50)]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
 p=root/(label+'.log');assert not p.exists()
 with p.open('w') as log:code=subprocess.call(['python3','/workspace/scratch/a1b6a42f71e7/run-gradle50.py','runGameTestServer','-PcontrolledGameTests=true','-PgameTestNamespace='+ns],stdout=log,stderr=subprocess.STDOUT)
 text=p.read_text();ok=code==0 and f'{n} GAME TESTS COMPLETE' in text and f'All {n} required tests passed' in text
 results.append({'label':label,'namespace':ns,'expected':n,'exit':code,'passed':ok,'source':source});(root/'completion-results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,code,ok,flush=True)
 if not ok:raise SystemExit(1)
