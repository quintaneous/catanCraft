import pathlib,hashlib,json,sys,subprocess
root=pathlib.Path('/workspace/scratch/a1b6a42f71e7/catanCraft');out=pathlib.Path(sys.argv[1]);files={}
for folder in ('build/classes/java/main','build/resources/main'):
 for p in sorted((root/folder).rglob('*')):
  if p.is_file():files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
value={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':files}
if out.exists():raise RuntimeError('Preserve existing evidence: '+str(out))
out.write_text(json.dumps(value,indent=2)+'\n');print(len(files),'compiled files recorded',out)
