import os,subprocess,urllib.parse,sys,pathlib,json
p=urllib.parse.urlparse(os.environ['HTTPS_PROXY']);env=dict(os.environ)
env['JAVA_HOME']='/workspace/scratch/a1b6a42f71e7/toolchain/jdk-17.0.21+9'
env['JAVA_TOOL_OPTIONS']=f'-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Dhttp.proxyHost={p.hostname} -Dhttp.proxyPort={p.port} -Dhttps.proxyHost={p.hostname} -Dhttps.proxyPort={p.port}'
env['GRADLE_OPTS']=''
gradle='/workspace/scratch/a1b6a42f71e7/toolchain/gradle-8.8/bin/gradle'
def run(args,log=None):
 return subprocess.call([gradle,*args,'--no-daemon','--max-workers=4'],env=env,stdout=log,stderr=subprocess.STDOUT if log else None)
# Match construction34-final.yml's required generated-flat bootstrap, sequentially.
# This wrapper never copies an owner/authored world; the repository preparer refuses it.
if '-PgameTestNamespace=catancraft_startup34' in sys.argv and not pathlib.Path('build/controlled-catancraft_startup34-run').exists():
 root=pathlib.Path('build/vehicle50-evidence/final');logpath=root/'startup-bootstrap.log'
 if logpath.exists() or pathlib.Path('build/controlled-catancraft_sector_prices-run').exists():raise RuntimeError('Preserve existing bootstrap evidence before rerunning')
 source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 with logpath.open('w') as log:code=run(['runGameTestServer','-PcontrolledGameTests=true','-PgameTestNamespace=catancraft_sector_prices'],log)
 text=logpath.read_text();ok=code==0 and '7 GAME TESTS COMPLETE' in text and 'All 7 required tests passed' in text
 (root/'startup-bootstrap-result.json').write_text(json.dumps({'expected':7,'exit':code,'passed':ok,'source':source},indent=2)+'\n')
 if not ok:raise SystemExit(code or 1)
 with (root/'startup-provenance.json').open('w') as out:code=subprocess.call([sys.executable,'-B','tools/construction34/prepare_startup_fixture.py'],stdout=out)
 if code:raise SystemExit(code)
raise SystemExit(run(sys.argv[1:]))
