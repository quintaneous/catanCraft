import json,pathlib,re,subprocess,sys,time,hashlib
repo=pathlib.Path('/workspace/scratch/a1b6a42f71e7/catanCraft')
source='27f62bd279a43b7604c24d857dcc16fe70ac5c00';label='vehicle52-round1'
out=repo/'build/vehicle52-evidence'/label
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert not (repo/'build'/('validation-'+label)).exists(), 'Never reuse a previous fresh run'
out.mkdir(parents=True)
wrapper='/workspace/scratch/a1b6a42f71e7/run-gradle50-original.py'
suites=[('catancraft_vehicle52',7,[],False),('catancraft_vehicle52_public',6,[],False),('catancraft_factory50',3,[],False),('catancraft_vehicle52_native',96,['-Pvehicle52Source='+source],True),('catancraft_vehicle50_ui',3,[],False),('catancraft_vehicle46',18,[],False),('catancraft_vehicle45',8,[],False),('catancraft_shop51',9,[],False),('catancraft_service50',8,[],True),('catancraft_vehicle47',4,['-Pvehicle47RestartSource='+source],True)]
for phase in ['seed','verify']:suites.append(('catancraft_service50_restart',1,['-Pservice50Phase='+phase,'-Pservice50Source='+source],True))
for phase in ['seed','verify']:suites.append(('catancraft_vehicle47_restart',1,['-Pvehicle47RestartPhase='+phase,'-Pvehicle47RestartSource='+source],True))
results=[]
for index,(namespace,expected,extra,combined) in enumerate(suites,1):
 name=f'{index:02d}-{namespace}';path=out/(name+'.log')
 command=[sys.executable,wrapper,'runGameTestServer','--offline','-PcontrolledGameTests=true','-PcontrolledRunLabel='+label,'-PgameTestNamespace='+namespace,*extra]
 if combined:command+=['-I','tools/vehicle52/validate_combined.gradle']
 started=time.time();print('RUN',name,'expected',expected,flush=True)
 with path.open('x') as log:code=subprocess.call(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 text=path.read_text();completed=re.findall(r'(\d+) GAME TESTS COMPLETE',text)
 passed=code==0 and completed and int(completed[-1])==expected and f'All {expected} required tests passed' in text
 row={'name':name,'namespace':namespace,'expected':expected,'executed':int(completed[-1]) if completed else 0,'exit':code,'passed':bool(passed),'seconds':round(time.time()-started,2),'command':command,'logSHA256':hashlib.sha256(path.read_bytes()).hexdigest()}
 results.append(row);(out/'results.json').write_text(json.dumps({'sourceCommit':source,'label':label,'results':results},indent=2)+'\n');print(json.dumps(row),flush=True)
 if not passed:print('STOP: failed attempt retained at',path,flush=True);sys.exit(code or 1)
print('VALIDATED_PHASE_EXECUTIONS',sum(r['executed'] for r in results),flush=True)
