import os,subprocess,urllib.parse,sys
p=urllib.parse.urlparse(os.environ['HTTPS_PROXY']);env=dict(os.environ)
env['JAVA_HOME']='/workspace/scratch/a1b6a42f71e7/toolchain/jdk-17.0.21+9'
env['JAVA_TOOL_OPTIONS']=f'-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Dhttp.proxyHost={p.hostname} -Dhttp.proxyPort={p.port} -Dhttps.proxyHost={p.hostname} -Dhttps.proxyPort={p.port}'
env['GRADLE_OPTS']=''
raise SystemExit(subprocess.call(['/workspace/scratch/a1b6a42f71e7/toolchain/gradle-8.8/bin/gradle',*sys.argv[1:],'--no-daemon','--max-workers=4'],env=env))
