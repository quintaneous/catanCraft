from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path('/workspace/scratch/a1b6a42f71e7/catanCraft');out=r/'build/vehicle52-evidence/vehicle52-round1';source='27f62bd279a43b7604c24d857dcc16fe70ac5c00'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==source
assert not subprocess.check_output(['git','diff',source,'--','src','build.gradle','tools/vehicle52'],cwd=r)
results=json.loads((out/'results.json').read_text());assert results['sourceCommit']==source and len(results['results'])==14
assert sum(x['executed'] for x in results['results'])==166
for x in results['results']:
 assert x['passed'] and x['exit']==0 and x['expected']==x['executed']
 assert h(out/(x['name']+'.log'))==x['logSHA256']
assert 'BUILD SUCCESSFUL' in (out/'build.log').read_text()
assert (out/'build-exit.txt').read_text().strip()=='0'
jar=r/'build/libs/catancraft-0.1.50-vehicle-service.jar'
original=r.parent/'deliverables/CatanCraft-0.1.50-solo-test.zip';assert h(original)=='e2ca84ee26b2a069792a643164ec42f747ce61b6a52714a7c17c4eac3b82a52b'
for a in ['967e9faaa2f954e51c7612a48551a9a33d50cad5','1cb34f3435bb9a7b733acc16864e5ffef049b8bb']:subprocess.run(['git','merge-base','--is-ancestor',a,source],cwd=r,check=True)
subprocess.run(['git','diff','--exit-code','715a22786c4bc050814b6e5b6130084a950f525c',source,'--','src/main/resources'],cwd=r,check=True)
files={p.name:p for p in sorted(out.glob('*.log'))};files['results.json']=out/'results.json';files['build-exit.txt']=out/'build-exit.txt'
for n in ['vehicle52-compile1.log','vehicle52-compile2.log','run-vehicle52-validation.py','run-gradle50-original.py','collect-vehicle52-evidence.py']:files['runner/'+n]=r.parent/n
archive=r/'docs/evidence/vehicle52_validation_evidence.zip'
inv={'sourceCommit':source,'files':{k:{'sha256':h(p),'bytes':p.stat().st_size} for k,p in files.items()}}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in files.items():z.writestr(n,p.read_bytes())
 z.writestr('INVENTORY.json',json.dumps(inv,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for n,v in inv['files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
nativeArchive=r/'docs/evidence/vehicle52_native_proofs.zip'
with zipfile.ZipFile(nativeArchive) as z:
 inventory=json.loads(z.read('INVENTORY.json'));native=[]
 for n,v in inventory['files'].items():
  raw=z.read(n);assert hashlib.sha256(raw).hexdigest()==v['sha256'];row=json.loads(raw);native.append(row)
  assert row['result']=='PASS' and row['source']==source and row['productionBayConstructed']
  assert row['sourceBeforeSHA256']==row['sourceAfterSHA256'] and row['sourceCellsUnchanged']==18400 and row['postSpawnPoseWrites']==0 and row['driverExitedAfterDeparture']
  assert len(row['seats'])==(9 if row['vehicle']=='sodayo_pick_up' else 6)
  assert row['trajectory'][-1]['energy']<row['initialEnergy'] and row['maxDistance']>=10
  assert row['legacyCityAPlot1BayExactlyEqual']==(row['city']=='a' and row['plot']=='plot_1')
assert len(native)==96 and len({(x['city'],x['plot'],x['vehicle']) for x in native})==96
brief=[]
for x in sorted(native,key=lambda x:x['case']):
 brief.append({k:x[k] for k in ['case','city','plot','vehicle','rotation','anchorX','anchorY','anchorZ','counterX','counterY','counterZ','result','sourceBeforeSHA256','sourceAfterSHA256','sourceCellsUnchanged','productionBayConstructed','legacyCityAPlot1BayExactlyEqual','maxDistance','maxYaw','driverExitedAfterDeparture']})
report={'schema':1,'dateUTC':'2026-11-14','status':'DEVELOPMENT_CHECKPOINT_NOT_OWNER_RELEASE','sourceCommit':source,'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=r,text=True).strip(),'branch':'chatgpt/combined-shop-acceptance','runtime':{'java':'17.0.21+9','gradle':'8.8','minecraft':'1.20.1','forge':'47.4.10','offline':True,'combinedPublishedArtifacts':15,'taczManifestSHA256':native[0]['taczRuntimeManifestSHA256'],'sbwManifestSHA256':native[0]['sbwRuntimeManifestSHA256'],'ownerInstalledPackAcceptance':False},'native':{'label':results['label'],'executedPhases':166,'passedPhases':166,'failedPhases':0,'restartPhases':4,'results':results['results']},'allCityGeometry':{'cases':96,'factorySites':48,'seatExits':sum(len(x['seats']) for x in native),'sourceCellChecks':sum(x['sourceCellsUnchanged'] for x in native),'legacyABayExactCases':2,'casesSummary':brief},'build':{'command':['build','--offline'],'exit':0,'logSHA256':h(out/'build.log'),'testTask':'NO-SOURCE; not counted as tests','artifact':{'path':str(jar.relative_to(r)),'sha256':h(jar),'bytes':jar.stat().st_size,'release':False,'note':'Development artifact retains old version filename. Not the delivered050 artifact or an owner install.'}},'retainedFailedAttempt':{'phase':'initial compile','reason':'Test helper omitted IOException declaration; corrected before source commit and successful compile/native validation.','log':'runner/vehicle52-compile1.log','logSHA256':h(r.parent/'vehicle52-compile1.log')},'preservation':{'resourcesByteIdenticalToDelivered050':True,'purchase033SourceAndDocsRetainedAsAncestors':True,'original050OwnerArchiveSHA256':h(original),'original050OwnerArchiveUnchanged':True,'liveWorldOrInstalledModsAccessed':False},'scopeLimits':['Actual-coordinate composed-source native fixtures; not a full authored world campaign.','Production Bay construction and native driving/seat exits; no positive authenticated-client counter purchase claimed.','Retained transaction/restart suites use their scoped synthetic authority fixtures.','Fractional credit remains unchanged in nation/vehicle keying; cross-factory authenticated refueling is not claimed.','Wall coverage, shared startup and complete clean-server packaging remain open.','No new cumulative no-grant campaign, 033/034 owner acceptance replay or prior entire shop/reward suite rerun.','SEC-01 crowbar remains UNRESOLVED / HIGH PRIORITY pending installed-pack acceptance.'],'evidence':[{'path':str(p.relative_to(r)),'sha256':h(p),'bytes':p.stat().st_size} for p in [archive,nativeArchive,r/'docs/evidence/vehicle52_geometry_audit.json',r/'docs/evidence/vehicle52_geometry_audit.py']]}
(r/'docs/evidence/vehicle52_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'source':source,'phases':166,'nativeCases':96,'artifact':report['build']['artifact'],'archives':report['evidence']},indent=2))
