# CatanCraft cloud environment validation

Repository: quintaneous/catanCraft, branch v0.1-foundation, commit d09f3544babeb2602261ddc2aeb90c34b8ff966e. Source and tracked files unchanged. Original work branch retained.

Runtime: Temurin 17.0.16+8, Gradle 8.8, Minecraft 1.20.1, Forge 47.4.10. Tool distributions were verified against publisher checksums.

Network policy: saved restricted policy contains the Package managers preset and all five requested additional hosts. Actual proxy connections to maven.minecraftforge.net, piston-meta.mojang.com, piston-data.mojang.com, libraries.minecraft.net, and resources.download.minecraft.net succeed. Actual ForgeGradle metadata and Minecraft manifest downloads passed; subsequent builds downloaded the dependencies and assets successfully. Network probe logs are in network-recheck/.

Activate in /workspace/catanCraft:

```bash
export JAVA_HOME=/workspace/toolchains/jdk-17.0.16+8
export PATH="$JAVA_HOME/bin:/workspace/toolchains/gradle-8.8/bin:$PATH"
export GRADLE_USER_HOME=/workspace/gradle-cache
```

The initial retry failed plugin resolution because Java needed explicit proxy/trust configuration. The successful standalone baseline command was:

```bash
gradle build --no-daemon --max-workers=4 -Dhttps.proxyHost=proxy -Dhttps.proxyPort=8080 -Dhttp.proxyHost=proxy -Dhttp.proxyPort=8080 -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts --info
```

Baseline: exit 0, BUILD SUCCESSFUL, 5m 53s, 7 tasks executed. Conventional test task: NO-SOURCE. Seven compiler deprecation warnings. Successful log: baseline-build-truststore.log. Earlier diagnostic attempts are retained separately.

Equivalent system properties are now stored in /workspace/gradle-cache/gradle.properties outside the repository. configure-gradle-proxy.sh preserves unrelated properties and was verified repeatable. TLS verification remained enabled; no proxy bypass or dependency-version changes were used.

Workflow fixture staging, verified before both native suites:

```bash
printf '%s\n' '39f2fda6a74d0d891d45b37d111079905a6f67e4261b591c13902b4215342c4b  tests/fixtures/thall4.schem' '1ea2fd544c32ed5506a553bf6c56628ecd4b7ac8d29257009e7bd84a427bbc06  tests/fixtures/thall5.schem' | sha256sum -c -
mkdir -p build/gametest-run/config/catancraft/schematics build/public-gametest-run/config/catancraft/schematics
cp tests/fixtures/thall*.schem build/gametest-run/config/catancraft/schematics/
cp tests/fixtures/thall*.schem build/public-gametest-run/config/catancraft/schematics/
```

Both hashes passed. Exact native commands, with the saved user properties active:

```bash
gradle build runGameTestServer --no-daemon --max-workers=4
gradle runGameTestServer -PgameTestNamespace=catancraft_public27 --no-daemon --max-workers=4
```

| Suite | Executed | Passed | Failed | Exit | Duration |
| --- | ---: | ---: | ---: | ---: | --- |
| catancraft | 50 | 50 | 0 | 0 | 12m 54s |
| catancraft_public27 | 11 | 11 | 0 | 0 | 6m 39s |

Each console log contains the expected enabled namespace, running count, completion count, all-required-tests-passed marker, and BUILD SUCCESSFUL. Console capture used pipefail and PIPESTATUS[0]; see gametest-retry-status.txt. Logs: catancraft-gametest-retry.log and public27-gametest-retry.log. Runtime logs are also copied to runtime-logs/; generated fixture evidence remains under the two build test worlds. No tests were disabled or modified.

Nonblocking runtime warnings included optional Forge update metadata at files.minecraftforge.net and authentication metadata at api.minecraftservices.com; both suites completed successfully despite these warnings. No additional access is required for the validated build/native-test workflow.

Built JAR: /workspace/catanCraft/build/libs/catancraft-0.1.27.jar
SHA-256: cdc90846cbf62d1323722c5aa41776b76be0253fec1222b74a8bcc020bb5d5b6

Saved draft fields: install_script and start_skill updated with proxy/trust preparation, tool activation, fixture staging, both namespaces, and verified results. Repository remains pinned to the recorded development commit. Saving the draft is not publication or proof of restoration in a new task.

No active Minecraft world, installed mods, or live server was accessed. Additional development handoff and Blender assets remain unconfirmed. Do not begin feature integration until they are available and their hashes have been checked.
