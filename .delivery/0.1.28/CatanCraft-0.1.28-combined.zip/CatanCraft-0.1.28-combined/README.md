# CatanCraft 0.1.28 combined review package

One combined JAR: precise entity hazards, free Producer Exterior R2, six free R5 house migrations, compatible initial R4-A/R6 defense purchases using approved provisional nation-stockpile costs. No deployment/publication or live-world access occurred.

Release/source commit: `a72e7b075235271ab23fe5ca78c9bbd91d918c92` on `codex/combined-integration`, based on `v0.1-foundation` `d09f3544babeb2602261ddc2aeb90c34b8ff966e`. Native validation ran with a clean tree at `c1097d38bd384135873b9375b0d21837dafad4a6`: baseline build PASS,101 native tests executed/passed,0 failed, all6 suite exit codes0. Final commit changes only INTEGRATION_STATUS.md; every runtime/build/test/CI/tool file matches TESTED_RUNTIME_PINS.json. Final reobfuscated JAR build passed and embeds the release commit. Source ZIP is an exact git archive of that release commit; integration.patch and CHECKPOINTS.txt support review.

Java17.0.16+8 / Gradle8.8 / Minecraft1.20.1 / Forge47.4.10. Prepared dependency cache was used with --offline; TLS/proxy behavior and dependency versions were not altered. Fresh online dependency restoration has not been recertified in this integration. Optional metadata/authentication warnings did not stop tests. Conventional Gradle test is NO-SOURCE; reported counts are actual native GameTests. Remote CI has not run.

Exact activation, fixture staging, commands and all per-suite console/exit evidence: INTEGRATION_STATUS.md, source tools/validate_combined.sh and evidence/final/. Both retained namespaces are included (50+11), plus integration12,producer9,houses11,defense8. All original28 resources/fixtures remain byte-identical to baseline. Earlier failed attempts and their corrections remain in evidence/. Native journals are from isolated disposable development worlds only.

Final JAR command: `gradle build -PreleaseCommit=a72e7b075235271ab23fe5ca78c9bbd91d918c92 --offline --no-daemon --max-workers=4` after Java/Gradle/cache activation documented in status.

Verify package files from this directory with `sha256sum -c SHA256SUMS.txt`. The single manual acceptance sequence is COMBINED_INGAME_CHECKLIST.md. Actual TaCZ/Superb Warfare use and visual lighting are pending that isolated check; native tests do not certify arbitrary process kills or a full modpack. Crowbar exploit remains **UNRESOLVED / HIGH PRIORITY**. No gates/trenches, rejected bunkers, pavilion, terrain rollout, multiplayer, merge/main/default-branch changes, force-push or server deployment.
